// ///File download from FlutterViz- Drag and drop a tools. For more details visit https://flutterviz.io/

// import 'package:aaaa/store.dart';
// import 'package:aaaa/video.dart';
// import 'package:flutter/material.dart';

// class Lactures extends StatelessWidget {
//   const Lactures({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: const Color(0xffffffff),
//       appBar: AppBar(
//         elevation: 4,
//         centerTitle: true,
//         automaticallyImplyLeading: false,
//         backgroundColor: const Color(0xffffffff),
//         shape: const RoundedRectangleBorder(
//           borderRadius: BorderRadius.zero,
//         ),
//         title: const Text(
//           "الدروس",
//           style: TextStyle(
//             fontWeight: FontWeight.w700,
//             fontStyle: FontStyle.normal,
//             fontSize: 18,
//             color: Color(0xff000000),
//           ),
//         ),
//         leading: const Icon(
//           Icons.list,
//           color: Color(0xffffffff),
//           size: 24,
//         ),
//         actions: [
//           const Icon(Icons.close, color: Color(0xffffffff), size: 24),
//         ],
//       ),
//       body: SingleChildScrollView(
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.start,
//           crossAxisAlignment: CrossAxisAlignment.start,
//           mainAxisSize: MainAxisSize.max,
//           children: [
//             GridView(
//               padding: const EdgeInsets.all(16),
//               shrinkWrap: true,
//               scrollDirection: Axis.vertical,
//               physics: const ClampingScrollPhysics(),
//               gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
//                 crossAxisCount: 2,
//                 crossAxisSpacing: 16,
//                 mainAxisSpacing: 16,
//                 childAspectRatio: 1,
//               ),
//               children: [
//                 Card(
//                   margin: const EdgeInsets.all(0),
//                   color: const Color(0xffffffff),
//                   shadowColor: const Color(0xff000000),
//                   elevation: 4,
//                   shape: RoundedRectangleBorder(
//                     borderRadius: BorderRadius.circular(8.0),
//                   ),
//                   child: Column(
//                     mainAxisAlignment: MainAxisAlignment.center,
//                     crossAxisAlignment: CrossAxisAlignment.center,
//                     mainAxisSize: MainAxisSize.max,
//                     children: [
//                       Container(
//                         alignment: Alignment.center,
//                         margin: const EdgeInsets.all(0),
//                         padding: const EdgeInsets.all(12),
//                         decoration: BoxDecoration(
//                           color: const Color(0x2d3a57e8),
//                           shape: BoxShape.circle,
//                           border: Border.all(
//                               color: const Color(0x4d9e9e9e), width: 1),
//                         ),
//                         child: const Icon(
//                           Icons.all_inclusive,
//                           color: Color(0xff000000),
//                           size: 24,
//                         ),
//                       ),
//                       const Padding(
//                         padding: EdgeInsets.fromLTRB(0, 12, 0, 8),
//                         child: Text(
//                           "Permanent Tasks",
//                           textAlign: TextAlign.center,
//                           maxLines: 1,
//                           overflow: TextOverflow.clip,
//                           style: TextStyle(
//                             fontWeight: FontWeight.w700,
//                             fontStyle: FontStyle.normal,
//                             fontSize: 16,
//                             color: Color(0xff000000),
//                           ),
//                         ),
//                       ),
//                       const Text(
//                         "10 Tasks",
//                         textAlign: TextAlign.start,
//                         overflow: TextOverflow.clip,
//                         style: TextStyle(
//                           fontWeight: FontWeight.w400,
//                           fontStyle: FontStyle.normal,
//                           fontSize: 14,
//                           color: Color(0xff363636),
//                         ),
//                       ),
//                     ],
//                   ),
//                 ),
//                 Card(
//                   margin: const EdgeInsets.all(0),
//                   color: const Color(0xffffffff),
//                   shadowColor: const Color(0xff000000),
//                   elevation: 4,
//                   shape: RoundedRectangleBorder(
//                     borderRadius: BorderRadius.circular(8.0),
//                   ),
//                   child: GestureDetector(
//                     onTap: () => Navigator.pushReplacement(
//                       context,
//                       MaterialPageRoute(
//                           builder: (context) => const General_viedo()),
//                     ),
//                     child: Column(
//                       mainAxisAlignment: MainAxisAlignment.center,
//                       crossAxisAlignment: CrossAxisAlignment.center,
//                       mainAxisSize: MainAxisSize.max,
//                       children: [
//                         Container(
//                           alignment: Alignment.center,
//                           margin: const EdgeInsets.all(0),
//                           padding: const EdgeInsets.all(12),
//                           decoration: const BoxDecoration(
//                             color: Color(0x2d3a57e8),
//                             shape: BoxShape.circle,
//                           ),
//                           child: const Icon(
//                             Icons.access_time,
//                             color: Color(0xff000000),
//                             size: 24,
//                           ),
//                         ),
//                         const Padding(
//                           padding: EdgeInsets.fromLTRB(0, 12, 0, 8),
//                           child: Text(
//                             "Current Tasks",
//                             textAlign: TextAlign.center,
//                             maxLines: 1,
//                             overflow: TextOverflow.clip,
//                             style: TextStyle(
//                               fontWeight: FontWeight.w700,
//                               fontStyle: FontStyle.normal,
//                               fontSize: 16,
//                               color: Color(0xff000000),
//                             ),
//                           ),
//                         ),
//                         const Text(
//                           "14 Tasks",
//                           textAlign: TextAlign.start,
//                           overflow: TextOverflow.clip,
//                           style: TextStyle(
//                             fontWeight: FontWeight.w400,
//                             fontStyle: FontStyle.normal,
//                             fontSize: 14,
//                             color: Color(0xff363636),
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                 ),
//                 Card(
//                   margin: const EdgeInsets.all(0),
//                   color: const Color(0xffffffff),
//                   shadowColor: const Color(0xff000000),
//                   elevation: 4,
//                   shape: RoundedRectangleBorder(
//                     borderRadius: BorderRadius.circular(8.0),
//                   ),
//                   child: GestureDetector(
//                     onTap: () => Navigator.pushReplacement(
//                       context,
//                       MaterialPageRoute(builder: (context) => const store()),
//                     ),
//                     child: Column(
//                       mainAxisAlignment: MainAxisAlignment.center,
//                       crossAxisAlignment: CrossAxisAlignment.center,
//                       mainAxisSize: MainAxisSize.max,
//                       children: [
//                         Container(
//                           alignment: Alignment.center,
//                           margin: const EdgeInsets.all(0),
//                           padding: const EdgeInsets.all(12),
//                           decoration: const BoxDecoration(
//                             color: Color(0x2d3a57e8),
//                             shape: BoxShape.circle,
//                           ),
//                           child: const Icon(
//                             Icons.store_mall_directory_outlined,
//                             color: Color(0xff000000),
//                             size: 24,
//                           ),
//                         ),
//                         const Padding(
//                           padding: EdgeInsets.fromLTRB(0, 12, 0, 8),
//                           child: Text(
//                             "Store ",
//                             textAlign: TextAlign.center,
//                             maxLines: 1,
//                             overflow: TextOverflow.clip,
//                             style: TextStyle(
//                               fontWeight: FontWeight.w700,
//                               fontStyle: FontStyle.normal,
//                               fontSize: 16,
//                               color: Color(0xff000000),
//                             ),
//                           ),
//                         ),
//                         const Text(
//                           "10 elements",
//                           textAlign: TextAlign.start,
//                           overflow: TextOverflow.clip,
//                           style: TextStyle(
//                             fontWeight: FontWeight.w400,
//                             fontStyle: FontStyle.normal,
//                             fontSize: 14,
//                             color: Color(0xff363636),
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                 ),
//                 Card(
//                   margin: const EdgeInsets.all(0),
//                   color: const Color(0xffffffff),
//                   shadowColor: const Color(0xff000000),
//                   elevation: 4,
//                   shape: RoundedRectangleBorder(
//                     borderRadius: BorderRadius.circular(8.0),
//                   ),
//                   child: GestureDetector(
//                     onTap: () => Navigator.pushReplacement(
//                       context,
//                       MaterialPageRoute(
//                           builder: (context) => const General_viedo()),
//                     ),
//                     child: Column(
//                       mainAxisAlignment: MainAxisAlignment.center,
//                       crossAxisAlignment: CrossAxisAlignment.center,
//                       mainAxisSize: MainAxisSize.max,
//                       children: [
//                         Container(
//                           alignment: Alignment.center,
//                           margin: const EdgeInsets.all(0),
//                           padding: const EdgeInsets.all(12),
//                           decoration: const BoxDecoration(
//                             color: Color(0x2d3a57e8),
//                             shape: BoxShape.circle,
//                           ),
//                           child: const Icon(
//                             Icons.alarm,
//                             color: Color(0xff000000),
//                             size: 24,
//                           ),
//                         ),
//                         const Padding(
//                           padding: EdgeInsets.fromLTRB(0, 12, 0, 8),
//                           child: Text(
//                             "Next Tasks",
//                             textAlign: TextAlign.center,
//                             maxLines: 1,
//                             overflow: TextOverflow.clip,
//                             style: TextStyle(
//                               fontWeight: FontWeight.w700,
//                               fontStyle: FontStyle.normal,
//                               fontSize: 16,
//                               color: Color(0xff000000),
//                             ),
//                           ),
//                         ),
//                         const Text(
//                           "100 Tasks",
//                           textAlign: TextAlign.start,
//                           overflow: TextOverflow.clip,
//                           style: TextStyle(
//                             fontWeight: FontWeight.w400,
//                             fontStyle: FontStyle.normal,
//                             fontSize: 14,
//                             color: Color(0xff363636),
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                 ),
//                 Card(
//                   margin: const EdgeInsets.all(0),
//                   color: const Color(0xffffffff),
//                   shadowColor: const Color(0xff000000),
//                   elevation: 4,
//                   shape: RoundedRectangleBorder(
//                     borderRadius: BorderRadius.circular(8.0),
//                   ),
//                   child: GestureDetector(
//                     onTap: () => Navigator.pushReplacement(
//                       context,
//                       MaterialPageRoute(
//                           builder: (context) => const General_viedo()),
//                     ),
//                     child: Column(
//                       mainAxisAlignment: MainAxisAlignment.center,
//                       crossAxisAlignment: CrossAxisAlignment.center,
//                       mainAxisSize: MainAxisSize.max,
//                       children: [
//                         Container(
//                           alignment: Alignment.center,
//                           margin: const EdgeInsets.all(0),
//                           padding: const EdgeInsets.all(12),
//                           decoration: const BoxDecoration(
//                             color: Color(0x2d3a57e8),
//                             shape: BoxShape.circle,
//                           ),
//                           child: const Icon(
//                             Icons.alarm,
//                             color: Color(0xff000000),
//                             size: 24,
//                           ),
//                         ),
//                         const Padding(
//                           padding: EdgeInsets.fromLTRB(0, 12, 0, 8),
//                           child: Text(
//                             "Next Tasks",
//                             textAlign: TextAlign.center,
//                             maxLines: 1,
//                             overflow: TextOverflow.clip,
//                             style: TextStyle(
//                               fontWeight: FontWeight.w700,
//                               fontStyle: FontStyle.normal,
//                               fontSize: 16,
//                               color: Color(0xff000000),
//                             ),
//                           ),
//                         ),
//                         const Text(
//                           "100 Tasks",
//                           textAlign: TextAlign.start,
//                           overflow: TextOverflow.clip,
//                           style: TextStyle(
//                             fontWeight: FontWeight.w400,
//                             fontStyle: FontStyle.normal,
//                             fontSize: 14,
//                             color: Color(0xff363636),
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                 ),
//                 Card(
//                   margin: const EdgeInsets.all(0),
//                   color: const Color(0xffffffff),
//                   shadowColor: const Color(0xff000000),
//                   elevation: 4,
//                   shape: RoundedRectangleBorder(
//                     borderRadius: BorderRadius.circular(8.0),
//                   ),
//                   child: GestureDetector(
//                     onTap: () => Navigator.pushReplacement(
//                       context,
//                       MaterialPageRoute(
//                           builder: (context) => const General_viedo()),
//                     ),
//                     child: Column(
//                       mainAxisAlignment: MainAxisAlignment.center,
//                       crossAxisAlignment: CrossAxisAlignment.center,
//                       mainAxisSize: MainAxisSize.max,
//                       children: [
//                         Container(
//                           alignment: Alignment.center,
//                           margin: const EdgeInsets.all(0),
//                           padding: const EdgeInsets.all(12),
//                           decoration: const BoxDecoration(
//                             color: Color(0x2d3a57e8),
//                             shape: BoxShape.circle,
//                           ),
//                           child: const Icon(
//                             Icons.alarm,
//                             color: Color(0xff000000),
//                             size: 24,
//                           ),
//                         ),
//                         const Padding(
//                           padding: EdgeInsets.fromLTRB(0, 12, 0, 8),
//                           child: Text(
//                             "Next Tasks",
//                             textAlign: TextAlign.center,
//                             maxLines: 1,
//                             overflow: TextOverflow.clip,
//                             style: TextStyle(
//                               fontWeight: FontWeight.w700,
//                               fontStyle: FontStyle.normal,
//                               fontSize: 16,
//                               color: Color(0xff000000),
//                             ),
//                           ),
//                         ),
//                         const Text(
//                           "100 Tasks",
//                           textAlign: TextAlign.start,
//                           overflow: TextOverflow.clip,
//                           style: TextStyle(
//                             fontWeight: FontWeight.w400,
//                             fontStyle: FontStyle.normal,
//                             fontSize: 14,
//                             color: Color(0xff363636),
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }

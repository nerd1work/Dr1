import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:flutter/material.dart';

Future<void> main() async {

  WidgetsFlutterBinding.ensureInitialized();

  await Supabase.initialize(

    url: 'https://jyetanbqwdnuoufhujbd.supabase.co',

    anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imp5ZXRhbmJxd2RudW91Zmh1amJkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MTE2MjgwMzQsImV4cCI6MjAyNzIwNDAzNH0.cxxODf52tKiag1w4m8Corcj8jzrtp2_6bO1w1v_sdgY',

  );

  runApp(MyApp());

}



            
class MyApp extends StatelessWidget {

  const MyApp({super.key});

  @override

  Widget build(BuildContext context) {

    return const MaterialApp(

      title: 'Countries',

      home: QuizzzPage(),

    );

  }

}



class QuizzzPage extends StatefulWidget {

  const QuizzzPage({Key? key});

  @override

  State<QuizzzPage> createState() => _QuizzzPageState();

}

class _QuizzzPageState extends State<QuizzzPage> {

  final _future = Supabase.instance.client.from('quiz_questions').select();

  int correctAnswersCount = 0;

  int wrongAnswersCount = 0;

  @override

  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(

        title: Text('الأسئلة'),

        centerTitle: true,

        automaticallyImplyLeading: false,

        leading: IconButton(

          icon: Icon(Icons.arrow_back),

          onPressed: () {

            Navigator.of(context).pop();

          },

        ),

      ),

      body: FutureBuilder(

        future: _future,

        builder: (context, snapshot) {

          if (snapshot.connectionState == ConnectionState.waiting) {

            return Center(child: CircularProgressIndicator());

          } else if (snapshot.hasError) {

            return Center(child: Text('Error: ${snapshot.error}'));

          } else {

            final questions = snapshot.data as List<dynamic>;

            return SingleChildScrollView(

              child: Column(

                crossAxisAlignment: CrossAxisAlignment.start,

                children: [

                  Padding(

                    padding: EdgeInsets.symmetric(vertical: 10, horizontal: 5),

                    child: SingleChildScrollView(

                      scrollDirection: Axis.horizontal,

                      child: Row(

                        children: [

                          Chip(

                            labelPadding: EdgeInsets.symmetric(vertical: 0, horizontal: 4),

                            label: Text("اجمالي الأسئلة: ${questions.length}"),

                            labelStyle: TextStyle(

                              fontSize: 14,

                              fontWeight: FontWeight.w400,

                              fontStyle: FontStyle.normal,

                              color: Color(0xffffffff),

                            ),

                            backgroundColor: Color(0xff000000),

                            elevation: 0,

                            shadowColor: Color(0xff808080),

                            shape: RoundedRectangleBorder(

                              borderRadius: BorderRadius.circular(16.0),

                            ),

                          ),

                          Chip(

                            labelPadding: EdgeInsets.symmetric(vertical: 0, horizontal: 4),

                            label: Text("الاجابات الصحيحة: $correctAnswersCount"),

                            labelStyle: TextStyle(

                              fontSize: 14,

                              fontWeight: FontWeight.w400,

                              fontStyle: FontStyle.normal,

                              color: Color(0xffffffff),

                            ),

                            backgroundColor: Colors.green,

                            elevation: 0,

                            shadowColor: Color(0xff808080),

                            shape: RoundedRectangleBorder(

                              borderRadius: BorderRadius.circular(16.0),

                            ),

                          ),

                          Chip(

                            labelPadding: EdgeInsets.symmetric(vertical: 0, horizontal: 4),

                            label: Text("الاجابات الخاطئة: $wrongAnswersCount"),

                            labelStyle: TextStyle(

                              fontSize: 14,

                              fontWeight: FontWeight.w400,

                              fontStyle: FontStyle.normal,

                              color: Color(0xffffffff),

                            ),

                            backgroundColor: Colors.red,

                            elevation: 0,

                            shadowColor: Color(0xff808080),

                            shape: RoundedRectangleBorder(

                              borderRadius: BorderRadius.circular(16.0),

                            ),

                          ),

                        ],

                      ),

                    ),

                  ),

                  Padding(

                    padding: const EdgeInsets.all(8.0),

                    child: Column(

                      crossAxisAlignment: CrossAxisAlignment.start,

                      children: questions.map<Widget>((questionData) {

                        return QuestionTile(

                          question: questionData['question'] ?? '',

                          answers: (questionData['answers'] as List<dynamic>).cast<String>(),

                          correctAnswer: questionData['correct_answer'] ?? '',

                          onAnswerSelected: (selectedAnswer) {

                            setState(() {

                              if (selectedAnswer == questionData['correct_answer']) {

                                correctAnswersCount++;

                              } else {

                                wrongAnswersCount++;

                              }

                            });

                          },

                        );

                      }).toList(),

                    ),

                  ),

                ],

              ),

            );

          }

        },

      ),

    );

  }

}

class QuestionTile extends StatefulWidget {

  final String question;

  final List<String> answers;

  final String correctAnswer;

  final Function(String) onAnswerSelected;

  const QuestionTile({

    Key? key,

    required this.question,

    required this.answers,

    required this.correctAnswer,

    required this.onAnswerSelected,

  }) : super(key: key);

  @override

  _QuestionTileState createState() => _QuestionTileState();

}

class _QuestionTileState extends State<QuestionTile> {

  String? selectedAnswer;

  @override

  Widget build(BuildContext context) {

    return Card(

      elevation: 4,

      shape: RoundedRectangleBorder(

        borderRadius: BorderRadius.circular(8.0),

      ),

      child: ExpansionTile(

        title: Text(

          widget.question,

          style: TextStyle(

            fontWeight: FontWeight.bold,

          ),

        ),

        children: widget.answers.map((answer) {

          return RadioListTile(

            title: Text(answer),

            value: answer,

            groupValue: selectedAnswer,

            onChanged: (String? value) {

              setState(() {

                selectedAnswer = value;

              });

              widget.onAnswerSelected(value!);

            },

            activeColor: selectedAnswer == widget.correctAnswer ? Colors.green : (selectedAnswer != null && selectedAnswer != widget.correctAnswer) ? Colors.red : null,

          );

        }).toList(),

      ),

    );

  }

}
            
                            
  
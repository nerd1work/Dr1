import 'package:flutter/material.dart';
import 'package:aaaa/kemia.dart';
class secondyear extends StatelessWidget {

  const secondyear({super.key});
  @override

  Widget build(BuildContext context) {

    return Scaffold(

      backgroundColor: Color(0xffebebeb),

      appBar: AppBar(

        elevation: 4,

        centerTitle: true,

        automaticallyImplyLeading: false,

        backgroundColor: Color(0xffffffff),

        shape: RoundedRectangleBorder(

          borderRadius: BorderRadius.zero,

        ),

        title: Text(

          "السنة الثانية",

          style: TextStyle(

            fontWeight: FontWeight.w700,

            fontStyle: FontStyle.normal,

            fontSize: 18,

            color: Color(0xff000000),

          ),

        ),

        leading: Icon(

          Icons.arrow_back,

          color: Color(0xff212435),

          size: 24,

        ),

      ),

      body: ListView(

        scrollDirection: Axis.vertical,

        padding: EdgeInsets.all(8),

        shrinkWrap: true,

        physics: ClampingScrollPhysics(),

        children: [

          GestureDetector(

            onTap: () {

              // Handle tap on year 2 card

              Navigator.push(

                context,

                MaterialPageRoute(builder: (context) => kimia1()),

              );

            },

            child: Card(

              margin: EdgeInsets.all(0),

              color: Color(0xffffffff),

              shadowColor: Color(0xff000000),

              elevation: 1,

              shape: RoundedRectangleBorder(

                borderRadius: BorderRadius.circular(12.0),

              ),

              child: Row(

                mainAxisAlignment: MainAxisAlignment.start,

                crossAxisAlignment: CrossAxisAlignment.start,

                mainAxisSize: MainAxisSize.min,

                children: [

                  ClipRRect(

                    borderRadius: BorderRadius.only(

                        topLeft: Radius.circular(12.0),

                        bottomLeft: Radius.circular(12.0)),

                    child: Image(

                      image: NetworkImage(

                          "https://tshrih.000webhostapp.com/lactures/IMG-20240418-WA0015.jpg"),

                      height: 130,

                      width: 100,

                      fit: BoxFit.cover,

                    ),

                  ),

                  Expanded(

                    flex: 1,

                    child: Padding(

                      padding: EdgeInsets.all(8),

                      child: Column(

                        mainAxisAlignment: MainAxisAlignment.start,

                        crossAxisAlignment: CrossAxisAlignment.start,

                        mainAxisSize: MainAxisSize.max,

                        children: [

                          Text(

                            "رحى 1 سفلية",

                            textAlign: TextAlign.start,

                            maxLines: 1,

                            overflow: TextOverflow.clip,

                            style: TextStyle(

                              fontWeight: FontWeight.w700,

                              fontStyle: FontStyle.normal,

                              fontSize: 16,

                              color: Color(0xff000000),

                            ),

                          ),

                          Padding(

                            padding: EdgeInsets.fromLTRB(0, 25, 0, 0),

                            child: Align(

                              alignment: Alignment.topLeft,

                              child: Text(

                                " لاستقبال تاج معدني",

                                textAlign: TextAlign.start,

                                maxLines: 1,

                                overflow: TextOverflow.clip,

                                style: TextStyle(

                                  fontWeight: FontWeight.w700,

                                  fontStyle: FontStyle.normal,

                                  fontSize: 12,

                                  color: Color(0xff7a7a7a),

                                ),

                              ),

                            ),

                          ),

                          Padding(

                            padding: EdgeInsets.fromLTRB(0, 4, 0, 0),

                            child: Text(

                              "",

                              textAlign: TextAlign.start,

                              maxLines: 2,

                              overflow: TextOverflow.clip,

                              style: TextStyle(

                                fontWeight: FontWeight.w700,

                                fontStyle: FontStyle.normal,

                                fontSize: 18,

                                color: Color(0xff000000),

                              ),

                            ),

                          ),

                        ],

                      ),

                    ),

                  ),

                  Padding(

                    padding: EdgeInsets.all(8),

                    child: Align(

                      alignment: Alignment.center,

                      child: Icon(

                        Icons.lock,

                        color: Color(0xff000000),

                        size: 24,

                      ),

                    ),

                  ),

                ],

              ),

            ),

          ),

          // Repeat the above structure for other cards

        ],

      ),

    );

  }

  // Function to navigate to the second page

  

}


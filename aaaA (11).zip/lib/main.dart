import 'package:aaaa/splash.dart';
import 'package:flutter/material.dart';
// import 'package:http/http.dart' as http;

// import 'dart:convert';
// import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'My App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const Splash(),
    );
  }
}

// // class LoginPage extends StatelessWidget {
// //   final TextEditingController usernameController = TextEditingController();

// //   final TextEditingController passwordController = TextEditingController();

// //   LoginPage({super.key});

// //   Future<void> _login(BuildContext context) async {
// //     final username = usernameController.text;

// //     final password = passwordController.text;

// //     final url = Uri.parse('https://tshrih.000webhostapp.com/Login/login.php');

// //     final response = await http.post(url, body: {
// //       'username': username,
// //       'password': password,
// //     });

// //     if (response.statusCode == 200) {
// //       final data = json.decode(response.body);

// //       if (data['success']) {
// //         ScaffoldMessenger.of(context).showSnackBar(
// //           const SnackBar(content: Text('تم تسجيل الدخول بنجاح')),
// //         );

// //         // حفظ معرف المستخدم أو اسم المستخدم في SharedPreferences

// //         SharedPreferences prefs = await SharedPreferences.getInstance();

// //         prefs.setString('username', username);
// //         prefs.setString('password', password);
// //         // إظهار Snackbar لتأكيد الحفظ

// //         ScaffoldMessenger.of(context).showSnackBar(
// //           const SnackBar(content: Text('تم حفظ المعرف في SharedPreferences')),
// //         );

// //         // نقل المستخدم إلى الصفحة الرئيسية

// //         Navigator.pushReplacement(
// //           context,
// //           MaterialPageRoute(builder: (context) => const Splash()),
// //         );
// //       } else {
// //         ScaffoldMessenger.of(context).showSnackBar(
// //           SnackBar(content: Text('خطأ: ${data['message']}')),
// //         );
// //       }
// //     } else {
// //       ScaffoldMessenger.of(context).showSnackBar(
// //         SnackBar(content: Text('خطأ: ${response.reasonPhrase}')),
// //       );
// //     }
// //   }

// //   @override
// //   Widget build(BuildContext context) {
// //     return Scaffold(
// //       appBar: AppBar(
// //         title: const Text('تسجيل الدخول'),
// //       ),
// //       body: Padding(
// //         padding: const EdgeInsets.all(20),
// //         child: Column(
// //           mainAxisAlignment: MainAxisAlignment.center,
// //           children: <Widget>[
// //             TextFormField(
// //               controller: usernameController,
// //               decoration: const InputDecoration(labelText: 'اسم المستخدم'),
// //             ),
// //             TextFormField(
// //               controller: passwordController,
// //               obscureText: true,
// //               decoration: const InputDecoration(labelText: 'كلمة المرور'),
// //             ),
// //             const SizedBox(height: 20),
// //             ElevatedButton(
// //               onPressed: () => _login(context),
// //               child: const Text('تسجيل الدخول'),
// //             ),
// //           ],
// //         ),
// //       ),
// //     );
// //   }
// // }

// import 'package:flutter/material.dart';
// import 'package:url_launcher/url_launcher.dart';

// void main() {
//   runApp(
//     const MaterialApp(
//       home: Scaffold(
//         body: Center(
//           child: ElevatedButton(
//             onPressed: _launchURL,
//             child: Text('Show Flutter homepage'),
//           ),
//         ),
//       ),
//     ),
//   );
// }

// _launchURL() async {
//   final Uri url =
//       Uri.parse('https://tshrih.000webhostapp.com/lactures/2year/kemia/1.pdf');
//   if (!await canLaunch(url.toString())) {
//     throw Exception('Could not launch $url');
//   } else {
//     await launch(url.toString());
//   }
// }

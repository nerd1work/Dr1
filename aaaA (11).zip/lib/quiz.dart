import 'package:flutter/material.dart';

class quizzzpage extends StatelessWidget {
  const quizzzpage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xffffffff),
      appBar: AppBar(
        elevation: 4,
        centerTitle: true,
        automaticallyImplyLeading: false,
        backgroundColor: Color(0xffffffff),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.zero,
        ),
        title: Text(
          "الأسئلة",
          style: TextStyle(
            fontWeight: FontWeight.w700,
            fontStyle: FontStyle.normal,
            fontSize: 16,
            color: Color(0xff000000),
          ),
        ),
        leading: Icon(
          Icons.arrow_back,
          color: Color(0xff212435),
          size: 24,
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: EdgeInsets.symmetric(vertical: 10, horizontal: 5),
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    Chip(
                      labelPadding:
                          EdgeInsets.symmetric(vertical: 0, horizontal: 4),
                      label: Text("اجمالي الأسئلة: 30"),
                      labelStyle: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                        fontStyle: FontStyle.normal,
                        color: Color(0xffffffff),
                      ),
                      backgroundColor: Color(0xff000000),
                      elevation: 0,
                      shadowColor: Color(0xff808080),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16.0),
                      ),
                    ),
                    Chip(
                      labelPadding:
                          EdgeInsets.symmetric(vertical: 0, horizontal: 4),
                      label: Text("الاجابات الصحيحة:10"),
                      labelStyle: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                        fontStyle: FontStyle.normal,
                        color: Color(0xffffffff),
                      ),
                      backgroundColor: Color(0xff000000),
                      elevation: 0,
                      shadowColor: Color(0xff808080),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16.0),
                      ),
                    ),
                    Chip(
                      labelPadding:
                          EdgeInsets.symmetric(vertical: 0, horizontal: 4),
                      label: Text("الاجابات الخاطئة: 10"),
                      labelStyle: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                        fontStyle: FontStyle.normal,
                        color: Color(0xffffffff),
                      ),
                      backgroundColor: Color(0xff000000),
                      elevation: 0,
                      shadowColor: Color(0xff808080),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16.0),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  QuestionTile(
                    question: "  quiz",
                    answers: ["answer_2", "answer_3", "answer_4", "answer_1"],
                  ),
                  SizedBox(height: 10),

                  // You can add more QuestionTiles here for more questions
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class QuestionTile extends StatefulWidget {
  final String question;
  final List<String> answers;

  const QuestionTile({
    Key? key,
    required this.question,
    required this.answers,
  }) : super(key: key);

  @override
  _QuestionTileState createState() => _QuestionTileState();
}

class _QuestionTileState extends State<QuestionTile> {
  String? selectedAnswer;

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8.0),
      ),
      child: ExpansionTile(
        title: Text(
          widget.question,
          style: TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
        children: widget.answers.map((answer) {
          return RadioListTile(
            title: Text(answer),
            value: answer,
            groupValue: selectedAnswer,
            onChanged: (String? value) {
              setState(() {
                selectedAnswer = value;
              });
            },
          );
        }).toList(),
      ),
    );
  }
}

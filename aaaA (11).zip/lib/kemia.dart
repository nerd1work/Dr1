import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';

class kimia1 extends StatefulWidget {
  const kimia1({super.key});

  @override
  _kimia1State createState() => _kimia1State();
}

class _kimia1State extends State<kimia1> {
  late String url = '';

  bool p1 = true;
  bool p2 = true;

  @override
  void initState() {
    super.initState();
    _loadPreferences();
    _fetchUrl();
  }

  _loadPreferences() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      p1 = prefs.getBool('p1') ?? true;
      p2 = prefs.getBool('p2') ?? true;
    });
  }

  _fetchUrl() async {
    final response = await http.get(Uri.parse(
        'https://tshrih.000webhostapp.com/lactures/2year/kemia/1.php'));
    if (response.statusCode == 200) {
      setState(() {
        Map<String, dynamic> data = jsonDecode(response.body);
        url = data['url1'] ?? '';
      });
    } else {
      showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text("خطأ"),
          content:
              const Text("حدث خطأ أثناء جلب البيانات. يرجى المحاولة مرة أخرى."),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
                _fetchUrl();
              },
              child: const Text("إعادة المحاولة"),
            ),
          ],
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("الكيمياء الحيوية الخاصة بالفم "),
      ),
      body: ListView(
        children: [
          buildCard(
            "talkhis title",
            "talkhis sub",
            p1,
            () {
              if (p1) {
                _launchURL(url);
              } else {
                showDialog(
                  context: context,
                  builder: (_) => const AlertDialog(
                    title: Text("تنبيه"),
                    content: Text("هذه المادة مغلقة. يرجى الشراء."),
                  ),
                );
              }
            },
          ),
          buildCard(
            "quiz title",
            "quiz sub",
            p2,
            () {
              if (p2) {
                _launchURL(url);
              } else {
                showDialog(
                  context: context,
                  builder: (_) => const AlertDialog(
                    title: Text("تنبيه"),
                    content: Text("هذه المادة مغلقة. يرجى الشراء."),
                  ),
                );
              }
            },
          ),
        ],
      ),
    );
  }

  Widget buildCard(String title, String subtitle, bool isOpen, Function onTap) {
    return Card(
      margin: const EdgeInsets.fromLTRB(0, 0, 0, 16),
      color: const Color(0xffffffff),
      shadowColor: const Color(0x4d939393),
      elevation: 1,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(4.0),
        side: const BorderSide(color: Color(0x4d9e9e9e), width: 1),
      ),
      child: InkWell(
        onTap: onTap as void Function()?,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisSize: MainAxisSize.max,
            children: [
              Container(
                alignment: Alignment.center,
                margin: const EdgeInsets.all(0),
                padding: const EdgeInsets.all(16),
                decoration: const BoxDecoration(
                  color: Color(0xfff2f2f2),
                  shape: BoxShape.circle,
                ),
                child: const Image(
                  image: NetworkImage(
                      "https://cdn.pixabay.com/photo/2016/09/14/20/50/tooth-1670434_1280.png"),
                  height: 20,
                  width: 20,
                  fit: BoxFit.cover,
                ),
              ),
              Expanded(
                flex: 1,
                child: Padding(
                  padding:
                      const EdgeInsets.symmetric(vertical: 0, horizontal: 16),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      Text(
                        title,
                        textAlign: TextAlign.start,
                        maxLines: 1,
                        overflow: TextOverflow.clip,
                        style: const TextStyle(
                          fontWeight: FontWeight.w700,
                          fontStyle: FontStyle.normal,
                          fontSize: 16,
                          color: Color(0xff000000),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.fromLTRB(0, 4, 0, 0),
                        child: Text(
                          subtitle,
                          textAlign: TextAlign.start,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            fontWeight: FontWeight.w400,
                            fontStyle: FontStyle.normal,
                            fontSize: 14,
                            color: Color(0xff6c6c6c),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Container(
                alignment: Alignment.center,
                margin: const EdgeInsets.all(0),
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: isOpen
                      ? const Color(0xffffffff)
                      : const Color(0xffffffff),
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  isOpen ? Icons.lock_open : Icons.lock,
                  color: isOpen
                      ? const Color(0xff000000)
                      : const Color(0xff000000),
                  size: 16,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _launchURL(String url) async {
    if (url.isNotEmpty) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => InAppWebViewPage(url: url),
        ),
      );
    } else {
      showDialog(
        context: context,
        builder: (_) => const AlertDialog(
          title: Text("تنبيه"),
          content: Text("المحتوى غير متوفر حاليًا."),
        ),
      );
    }
  }
}

class InAppWebViewPage extends StatefulWidget {
  final String url;

  const InAppWebViewPage({Key? key, required this.url}) : super(key: key);

  @override
  _InAppWebViewPageState createState() => _InAppWebViewPageState();
}

class _InAppWebViewPageState extends State<InAppWebViewPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("InAppWebView"),
      ),
      body: InAppWebView(
        initialUrlRequest: URLRequest(url: Uri.parse(widget.url)),
      ),
    );
  }
}
